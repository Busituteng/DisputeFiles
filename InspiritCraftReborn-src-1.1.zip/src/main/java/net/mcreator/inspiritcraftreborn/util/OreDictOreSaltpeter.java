
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.block.BlockNiterore;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictOreSaltpeter extends ElementsInspiritCraftReborn.ModElement {
	public OreDictOreSaltpeter(ElementsInspiritCraftReborn instance) {
		super(instance, 33);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreSaltpeter", new ItemStack(BlockNiterore.block, (int) (1)));
	}
}
