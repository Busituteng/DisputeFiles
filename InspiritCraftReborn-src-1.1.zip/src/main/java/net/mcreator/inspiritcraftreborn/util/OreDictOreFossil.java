
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.block.BlockFossil3;
import net.mcreator.inspiritcraftreborn.block.BlockFossil2;
import net.mcreator.inspiritcraftreborn.block.BlockFossil1;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictOreFossil extends ElementsInspiritCraftReborn.ModElement {
	public OreDictOreFossil(ElementsInspiritCraftReborn instance) {
		super(instance, 37);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreFossil", new ItemStack(BlockFossil1.block, (int) (1)));
		OreDictionary.registerOre("oreFossil", new ItemStack(BlockFossil2.block, (int) (1)));
		OreDictionary.registerOre("oreFossil", new ItemStack(BlockFossil3.block, (int) (1)));
	}
}
