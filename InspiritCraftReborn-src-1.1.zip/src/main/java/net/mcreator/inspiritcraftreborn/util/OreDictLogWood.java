
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.block.BlockKindlewood;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictLogWood extends ElementsInspiritCraftReborn.ModElement {
	public OreDictLogWood(ElementsInspiritCraftReborn instance) {
		super(instance, 35);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("logWood", new ItemStack(BlockKindlewood.block, (int) (1)));
	}
}
