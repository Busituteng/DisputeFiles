
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.block.BlockSulfurore;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictOreSulfur extends ElementsInspiritCraftReborn.ModElement {
	public OreDictOreSulfur(ElementsInspiritCraftReborn instance) {
		super(instance, 34);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreSulfur", new ItemStack(BlockSulfurore.block, (int) (1)));
	}
}
