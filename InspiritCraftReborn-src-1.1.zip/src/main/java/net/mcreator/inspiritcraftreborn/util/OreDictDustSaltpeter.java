
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.item.ItemNiter;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictDustSaltpeter extends ElementsInspiritCraftReborn.ModElement {
	public OreDictDustSaltpeter(ElementsInspiritCraftReborn instance) {
		super(instance, 32);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("dustSaltpeter", new ItemStack(ItemNiter.block, (int) (1)));
	}
}
