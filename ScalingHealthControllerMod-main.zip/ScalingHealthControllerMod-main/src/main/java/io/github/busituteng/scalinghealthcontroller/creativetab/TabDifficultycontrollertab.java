
package io.github.busituteng.scalinghealthcontroller.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import io.github.busituteng.scalinghealthcontroller.item.ItemDifficultycontroller;
import io.github.busituteng.scalinghealthcontroller.ElementsScalingHealthControllerMod;

@ElementsScalingHealthControllerMod.ModElement.Tag
public class TabDifficultycontrollertab extends ElementsScalingHealthControllerMod.ModElement {
	public TabDifficultycontrollertab(ElementsScalingHealthControllerMod instance) {
		super(instance, 3);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabdifficultycontrollertab") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemDifficultycontroller.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static CreativeTabs tab;
}
