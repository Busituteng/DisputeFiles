# Scaling Health控制器 (Scaling Health Controller Mod)
这是一个 [Scaling Health](https://legacy.curseforge.com/minecraft/mc-mods/scaling-health) 模组的拓展模组。  
This is an additional mod of [Scaling Health](https://legacy.curseforge.com/minecraft/mc-mods/scaling-health) mod.  
模组添加了一个难度控制器用于调节游戏的难度。  
The mod added an item with the name of "difficulty controller" to change the difficulty in the game.  
模组需要 Scaling Health 作为前置模组。  
The mod requires Scaling Health Mod.  
这个模组因 MCr 自身问题已停止开发。  
This mod has stopped to make because of MCreator's own problems.
